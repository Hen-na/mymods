package com.lidar.mixin;

import com.lidar.LidarVision;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.framegraph.FrameGraphBuilder;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Blacks out the world while the LiDAR scanner is held.
 *
 * <p>Each vanilla pass that would draw the environment is skipped individually rather than
 * cancelling the whole level render, because the particle pass has to keep running: the point
 * cloud is made of particles and is the only thing the player is meant to see.
 */
@Mixin(LevelRenderer.class)
public class LevelRendererMixin {
	/**
	 * The frame is cleared to the fog colour, which is what remains once every pass below is
	 * skipped. Replacing the local rather than mutating it avoids touching the caller's vector.
	 */
	@ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
	private Vector4f lidar$blackBackground(final Vector4f fogColor) {
		return LidarVision.isDarknessActive() ? new Vector4f(0.0F, 0.0F, 0.0F, 0.0F) : fogColor;
	}

	@Inject(method = "addSkyPass", at = @At("HEAD"), cancellable = true)
	private void lidar$hideSky(final FrameGraphBuilder frame, final CameraRenderState cameraState,
			final GpuBufferSlice skyFog, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}

	@Inject(method = "addCloudsPass", at = @At("HEAD"), cancellable = true)
	private void lidar$hideClouds(final FrameGraphBuilder frame, final CloudStatus cloudStatus, final Vec3 pos,
			final long gameTime, final float partialTick, final int cloudColor, final float cloudHeight,
			final int cloudRange, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}

	@Inject(method = "addWeatherPass", at = @At("HEAD"), cancellable = true)
	private void lidar$hideWeather(final FrameGraphBuilder frame, final GpuBufferSlice fog, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}

	@Inject(method = "submitEntities", at = @At("HEAD"), cancellable = true)
	private void lidar$hideEntities(final PoseStack poseStack, final LevelRenderState levelRenderState,
			final SubmitNodeCollector collector, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}

	@Inject(method = "submitBlockEntities", at = @At("HEAD"), cancellable = true)
	private void lidar$hideBlockEntities(final PoseStack poseStack, final LevelRenderState levelRenderState,
			final SubmitNodeCollector collector, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}

	/** Otherwise the targeted block's outline would trace geometry the player should not see. */
	@Inject(method = "submitBlockOutline", at = @At("HEAD"), cancellable = true)
	private void lidar$hideBlockOutline(final PoseStack poseStack, final SubmitNodeCollector collector,
			final LevelRenderState levelRenderState, final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}
}
