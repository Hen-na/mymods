package com.lidar.mixin;

import com.lidar.LidarVision;

import net.minecraft.client.particle.Particle;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Particles are normally lit by the level's light map, which would leave the point cloud
 * invisible in exactly the dark places the scanner exists for. While the scanner is held the
 * points are drawn at full brightness so they read against the blacked-out world.
 */
@Mixin(Particle.class)
public class ParticleMixin {
	/** Block light 15 and sky light 15, i.e. {@code 15 << 4 | 15 << 20}. */
	private static final int FULL_BRIGHT = 15728880;

	@Inject(method = "getLightCoords", at = @At("HEAD"), cancellable = true)
	private void lidar$fullBright(final float partialTick, final CallbackInfoReturnable<Integer> cir) {
		if (LidarVision.isDarknessActive()) {
			cir.setReturnValue(FULL_BRIGHT);
		}
	}
}
