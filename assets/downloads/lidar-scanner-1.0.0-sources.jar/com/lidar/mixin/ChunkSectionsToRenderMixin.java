package com.lidar.mixin;

import com.lidar.LidarVision;

import com.mojang.blaze3d.textures.GpuSampler;

import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Skips drawing terrain, which is what actually makes the world go black. */
@Mixin(ChunkSectionsToRender.class)
public class ChunkSectionsToRenderMixin {
	@Inject(method = "renderGroup", at = @At("HEAD"), cancellable = true)
	private void lidar$hideTerrain(final ChunkSectionLayerGroup group, final GpuSampler sampler,
			final CallbackInfo ci) {
		if (LidarVision.isDarknessActive()) {
			ci.cancel();
		}
	}
}
