package com.lidar.mixin;

import com.lidar.LidarVision;

import net.minecraft.client.renderer.ItemInHandRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Keeps whatever the player is holding visible in first person.
 *
 * <p>The held item is lit by the level light map, which in the blacked-out world resolves to
 * roughly zero, so the model is drawn but comes out black on black. Forcing the light the
 * renderer was handed to full bright makes it read as a physical device being carried.
 */
@Mixin(ItemInHandRenderer.class)
public class ItemInHandRendererMixin {
	/** Block light 15 and sky light 15, i.e. {@code 15 << 4 | 15 << 20}. */
	private static final int FULL_BRIGHT = 15728880;

	@ModifyVariable(method = "submitHandsWithItems", at = @At("HEAD"), argsOnly = true)
	private int lidar$litHand(final int lightCoords) {
		return LidarVision.isDarknessActive() ? FULL_BRIGHT : lightCoords;
	}
}
