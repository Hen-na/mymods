package com.lidar;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Projects a red particle circle onto the first block in front of the player
 * while the use key (RMB) is held, and samples the geometry inside that circle
 * into the {@link LidarVision} point cloud.
 *
 * <p>Holding the key keeps the item "in use", so the vanilla client keeps calling
 * {@link #onUseTick} every tick and stops the moment the key is released.
 */
public class LidarScannerItem extends Item {
	/** Vanilla {@code minecraft:dust} particle, pure red. The reduced scale keeps the dots small. */
	private static final DustParticleOptions BEAM_PARTICLE = new DustParticleOptions(0xFF0000, 0.5F);

	/** Diameter of the scanning circle projected onto the scanned surface, in blocks. */
	private static final double SCAN_DIAMETER = 6.0;

	/** Gap between the concentric rings that fill the circle, in blocks. */
	private static final double RING_SPACING = 0.5;

	/** Gap between neighbouring particles along a ring, in blocks. */
	private static final double ARC_SPACING = 0.4;

	/** How far off the surface the circle sits, so it is not buried inside the block. */
	private static final double SURFACE_OFFSET = 0.02;

	/** Gap between particles along the beam that links the scanner to the circle, in blocks. */
	private static final double BEAM_SPACING = 0.25;

	/** Keeps the sampling cone sane when the scanner is held right up against a surface. */
	private static final double MAX_CONE_HALF_ANGLE = Math.toRadians(40.0);

	public LidarScannerItem(final Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(final Level level, final Player player, final InteractionHand hand) {
		// Puts the item in use, which is what makes the "held" part of hold-RMB work.
		return ItemUtils.startUsingInstantly(level, player, hand);
	}

	@Override
	public int getUseDuration(final ItemStack stack, final LivingEntity entity) {
		return APPROXIMATELY_INFINITE_USE_DURATION;
	}

	@Override
	public ItemUseAnimation getUseAnimation(final ItemStack stack) {
		return ItemUseAnimation.NONE;
	}

	@Override
	public void onUseTick(final Level level, final LivingEntity entity, final ItemStack stack, final int remainingUseTicks) {
		// The scan is purely visual, so it is only drawn on the client.
		if (!level.isClientSide() || !(entity instanceof Player player)) {
			return;
		}

		// First block along the view direction, within the normal block interaction range.
		// A miss returns the far end of the ray, so the scan is always bounded.
		HitResult hit = player.pick(player.blockInteractionRange(), 1.0F, false);

		// The circle lies flat on the scanned surface. With no block hit there is no
		// surface to lie on, so it faces the player instead.
		Vec3 normal = hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit
				? blockHit.getDirection().getUnitVec3()
				: player.getViewVector(1.0F).reverse();

		Vec3 center = hit.getLocation().add(normal.scale(SURFACE_OFFSET));

		drawScanPulse(level, center, normal);
		drawScanBeam(level, player, center);

		// Fill the point cloud by sampling the geometry inside the same cone that the
		// circle above spans, so the revealed points line up with the visible scan area.
		Vec3 eye = player.getEyePosition(1.0F);
		double distance = Math.max(hit.getLocation().subtract(eye).length(), 1.5);
		double coneHalfAngle = Math.min(Math.atan(SCAN_DIAMETER / 2.0 / distance), MAX_CONE_HALF_ANGLE);
		LidarVision.scan(level, player, coneHalfAngle);
	}

	/**
	 * One pulse of the active scan: a bright centre that expands outward to the rim of the
	 * circular scan area and then starts again, repeating for as long as the key is held.
	 */
	private static void drawScanPulse(final Level level, final Vec3 center, final Vec3 normal) {
		// Two perpendicular axes spanning the plane of that surface.
		Vec3 seed = Math.abs(normal.y) > 0.9 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(0.0, 1.0, 0.0);
		Vec3 axisU = normal.cross(seed).normalize();
		Vec3 axisV = normal.cross(axisU).normalize();

		// The centre is always lit, so the pulse visibly starts from the scan direction.
		level.addParticle(BEAM_PARTICLE, center.x, center.y, center.z, 0.0, 0.0, 0.0);

		// Shares the sampling sweep's clock, so the red pulse and the rays that generate points
		// expand together instead of drifting out of step.
		double phase = (level.getGameTime() % LidarVision.SWEEP_PERIOD_TICKS)
				/ (double) LidarVision.SWEEP_PERIOD_TICKS;
		double reach = phase * (SCAN_DIAMETER / 2.0);

		for (double radius = RING_SPACING; radius <= reach; radius += RING_SPACING) {
			int points = Math.max(8, (int) Math.round(2.0 * Math.PI * radius / ARC_SPACING));
			for (int i = 0; i < points; i++) {
				double angle = 2.0 * Math.PI * i / points;
				Vec3 point = center
						.add(axisU.scale(Math.cos(angle) * radius))
						.add(axisV.scale(Math.sin(angle) * radius));
				level.addParticle(BEAM_PARTICLE, point.x, point.y, point.z, 0.0, 0.0, 0.0);
			}
		}
	}

	/** Links the scanner to the area it is currently scanning. */
	private static void drawScanBeam(final Level level, final Player player, final Vec3 center) {
		Vec3 start = scannerMuzzle(player);
		Vec3 beam = center.subtract(start);
		double length = beam.length();
		if (length < BEAM_SPACING) {
			return;
		}

		Vec3 step = beam.scale(BEAM_SPACING / length);
		int steps = (int) (length / BEAM_SPACING);
		for (int i = 0; i <= steps; i++) {
			Vec3 point = start.add(step.scale(i));
			level.addParticle(BEAM_PARTICLE, point.x, point.y, point.z, 0.0, 0.0, 0.0);
		}
	}

	/** Point the beam is drawn from: roughly where the held scanner sits on screen. */
	private static Vec3 scannerMuzzle(final Player player) {
		Vec3 eye = player.getEyePosition(1.0F);
		Vec3 look = player.getViewVector(1.0F);
		// Horizontal vector pointing to the player's right; zero when looking straight up or down.
		Vec3 side = new Vec3(-look.z, 0.0, look.x).normalize();

		boolean heldOnMainArmSide = (player.getUsedItemHand() == InteractionHand.MAIN_HAND)
				== (player.getMainArm() == HumanoidArm.RIGHT);

		return eye.add(look.scale(0.35))
				.add(side.scale(heldOnMainArmSide ? 0.25 : -0.25))
				.subtract(0.0, 0.12, 0.0);
	}
}
