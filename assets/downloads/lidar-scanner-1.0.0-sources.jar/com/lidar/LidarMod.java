package com.lidar;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;

public class LidarMod implements ModInitializer {
	public static final String MOD_ID = "lidar";

	public static final ResourceKey<Item> LIDAR_SCANNER_KEY =
			ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, "lidar_scanner"));

	public static final Item LIDAR_SCANNER =
			new LidarScannerItem(new Item.Properties().setId(LIDAR_SCANNER_KEY));

	/**
	 * Key of the vanilla "Tools & Utilities" creative tab. The constants on
	 * {@code CreativeModeTabs} are not public in 26.2, so the key is rebuilt here
	 * exactly the way vanilla builds it.
	 */
	private static final ResourceKey<CreativeModeTab> TOOLS_AND_UTILITIES =
			ResourceKey.create(Registries.CREATIVE_MODE_TAB, Identifier.withDefaultNamespace("tools_and_utilities"));

	@Override
	public void onInitialize() {
		Registry.register(BuiltInRegistries.ITEM, LIDAR_SCANNER_KEY, LIDAR_SCANNER);

		CreativeModeTabEvents.modifyOutputEvent(TOOLS_AND_UTILITIES)
				.register(output -> output.accept(LIDAR_SCANNER));
	}

	public static Identifier id(final String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
