package com.lidar.client;

import com.lidar.LidarVision;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;

import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector3f;

/**
 * Draws the point cloud as one batch of camera-facing quads.
 *
 * <p>This does not use particles. Vanilla caps a particle group at 16384 live particles and
 * starts randomly dropping new ones above 12288, so a cloud of this size would silently thin
 * out and flicker. Submitting the geometry directly has no such ceiling and costs one draw.
 */
public final class LidarCloudRenderer {
	/** Half-extent of a point quad, in blocks. Matches the previous point size exactly. */
	private static final float POINT_HALF_SIZE = 0.02F;

	private LidarCloudRenderer() {
	}

	public static void register() {
		LevelRenderEvents.COLLECT_SUBMITS.register(context -> {
			if (!LidarVision.isDarknessActive()) {
				return;
			}

			CameraRenderState camera = context.levelState().cameraRenderState;
			Vec3 cameraPos = camera.pos;

			// One orientation for the whole cloud: every point is a billboard facing the camera.
			Vector3f right = camera.orientation.transform(new Vector3f(POINT_HALF_SIZE, 0.0F, 0.0F));
			Vector3f up = camera.orientation.transform(new Vector3f(0.0F, POINT_HALF_SIZE, 0.0F));

			context.submitNodeCollector().submitCustomGeometry(
					context.poseStack(),
					RenderTypes.debugQuads(),
					(pose, consumer) -> LidarVision.forEachVisiblePoint(cameraPos, (x, y, z, argb) -> {
						// Vertices are camera-relative, which also keeps them in float range.
						float cx = (float) (x - cameraPos.x);
						float cy = (float) (y - cameraPos.y);
						float cz = (float) (z - cameraPos.z);

						consumer.addVertex(pose, cx - right.x - up.x, cy - right.y - up.y, cz - right.z - up.z)
								.setColor(argb);
						consumer.addVertex(pose, cx - right.x + up.x, cy - right.y + up.y, cz - right.z + up.z)
								.setColor(argb);
						consumer.addVertex(pose, cx + right.x + up.x, cy + right.y + up.y, cz + right.z + up.z)
								.setColor(argb);
						consumer.addVertex(pose, cx + right.x - up.x, cy + right.y - up.y, cz + right.z - up.z)
								.setColor(argb);
					}));
		});
	}
}
