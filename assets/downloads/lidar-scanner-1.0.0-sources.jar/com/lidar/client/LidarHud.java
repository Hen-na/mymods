package com.lidar.client;

import com.lidar.LidarMod;
import com.lidar.LidarVision;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;

/** Compact scanner readout, drawn top-left while the scanner is held. */
public class LidarHud implements HudElement {
	private static final int MARGIN = 4;
	private static final int PADDING = 3;

	private static final int BACKGROUND = 0xFF000000;
	private static final int TEXT = 0xFFE0E0E0;
	private static final int TITLE = 0xFFFFFFFF;
	private static final int BAR_TRACK = 0xFF555555;
	private static final int BAR_FILL = 0xFFFFFFFF;

	private static final int BAR_WIDTH = 60;
	private static final int BAR_HEIGHT = 5;
	private static final int BAR_GAP = 4;

	@Override
	public void extractRenderState(final GuiGraphicsExtractor graphics, final DeltaTracker deltaTracker) {
		Minecraft client = Minecraft.getInstance();
		LocalPlayer player = client.player;

		if (player == null || !LidarVision.isHoldingScanner()) {
			return;
		}

		int points = LidarVision.activePoints();
		int capacity = LidarVision.maxPoints();
		int usage = capacity == 0 ? 0 : (int) (points * 100L / capacity);

		String[] lines = {
			"LIDAR",
			"STATUS: " + (isScanning(player) ? "SCANNING" : "IDLE"),
			"RANGE: " + LidarVision.scanRange() + "m",
			"POINTS: " + points,
			"MEMORY: " + usage + "%",
		};

		Font font = client.font;
		int lineHeight = font.lineHeight;
		int memoryLine = lines.length - 1;

		int textWidth = 0;
		for (String line : lines) {
			textWidth = Math.max(textWidth, font.width(line));
		}
		textWidth = Math.max(textWidth, font.width(lines[memoryLine]) + BAR_GAP + BAR_WIDTH);

		int width = textWidth + PADDING * 2;
		int height = lines.length * lineHeight + PADDING * 2;

		graphics.fill(MARGIN, MARGIN, MARGIN + width, MARGIN + height, BACKGROUND);

		for (int i = 0; i < lines.length; i++) {
			graphics.text(font, lines[i], MARGIN + PADDING, MARGIN + PADDING + i * lineHeight,
					i == 0 ? TITLE : TEXT);
		}

		int barX = MARGIN + PADDING + font.width(lines[memoryLine]) + BAR_GAP;
		int barY = MARGIN + PADDING + memoryLine * lineHeight + (lineHeight - BAR_HEIGHT) / 2;
		int filled = Math.round(BAR_WIDTH * (usage / 100.0F));

		graphics.fill(barX, barY, barX + BAR_WIDTH, barY + BAR_HEIGHT, BAR_TRACK);
		if (filled > 0) {
			graphics.fill(barX, barY, barX + filled, barY + BAR_HEIGHT, BAR_FILL);
		}
	}

	/** Scanning is exactly "the scanner is the item currently being used", i.e. RMB is held. */
	private static boolean isScanning(final LocalPlayer player) {
		return player.isUsingItem() && player.getUseItem().getItem() == LidarMod.LIDAR_SCANNER;
	}
}
