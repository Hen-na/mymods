package com.lidar.client;

import com.lidar.LidarMod;
import com.lidar.LidarVision;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;

import org.lwjgl.glfw.GLFW;

/**
 * Drives the LiDAR vision mode. The mode is on exactly while the player holds the scanner,
 * so equipping it is what plunges the world into darkness and puts them on the scanner.
 */
public class LidarClient implements ClientModInitializer {
	private static final KeyMapping VISION_TOGGLE = new KeyMapping(
			"key.lidar.toggle_vision", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, KeyMapping.Category.MISC);

	@Override
	public void onInitializeClient() {
		KeyMappingHelper.registerKeyMapping(VISION_TOGGLE);
		LidarCloudRenderer.register();
		LidarMobScanner.register();
		HudElementRegistry.addLast(LidarMod.id("lidar_hud"), new LidarHud());

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			LocalPlayer player = client.player;
			ClientLevel level = client.level;

			if (player == null || level == null) {
				LidarVision.reset();
				return;
			}

			// Darkness is a property of the world, not of the held item, so it is on for as long
			// as the player is in a level. Only the HUD tracks what is in their hand.
			// consumeClick drains one queued press at a time, so holding the key cannot retrigger.
			while (VISION_TOGGLE.consumeClick()) {
				LidarVision.toggleVisionMode();
			}

			LidarVision.setDarknessActive(true);
			LidarVision.setHoldingScanner(isHoldingScanner(player));
			LidarVision.tick();
		});
	}

	private static boolean isHoldingScanner(final LocalPlayer player) {
		return player.getMainHandItem().getItem() == LidarMod.LIDAR_SCANNER
				|| player.getOffhandItem().getItem() == LidarMod.LIDAR_SCANNER;
	}
}
