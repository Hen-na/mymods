package com.lidar.client;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lidar.LidarVision;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector3f;

/**
 * Turns living entities inside the scan cone into LiDAR points.
 *
 * <p>The silhouette comes from the mob's own render model: the part tree is walked with its
 * accumulated transforms and points are scattered over each cube's surface, so a spider keeps
 * its legs and a creeper its four-footed shape without reproducing any texture.
 *
 * <p>Nothing here touches the mob. It reads position and model pose and writes points; the
 * entity itself is never modified, moved, copied or interacted with.
 */
public final class LidarMobScanner {
	/** Spacing of surface samples across a model cube, in model units (1/16 of a block). */
	private static final float SAMPLE_STEP = 3.0F;

	/** Model units to blocks. */
	private static final float MODEL_SCALE = 1.0F / 16.0F;

	/** Widening applied to the cone for mobs, so a body clipping the edge still registers. */
	private static final double CONE_MARGIN = 0.15;

	/** Averaged texture colour per mob texture, so each texture is decoded at most once. */
	private static final Map<Identifier, Integer> TEXTURE_COLORS = new HashMap<>();

	private LidarMobScanner() {
	}

	public static void register() {
		LidarVision.setMobSampler(LidarMobScanner::sample);
	}

	private static void sample(final Level level, final Player player, final double coneHalfAngle) {
		double range = LidarVision.scanRange();
		Vec3 eye = player.getEyePosition(1.0F);
		Vec3 look = player.getViewVector(1.0F);

		// Only entities near the scanner are considered; the rest of the world is never touched.
		AABB searchBox = new AABB(eye, eye).inflate(range);
		List<LivingEntity> mobs = level.getEntities(
				EntityTypeTest.forClass(LivingEntity.class), searchBox,
				candidate -> candidate != player && candidate.isAlive());

		double cosLimit = Math.cos(Math.min(coneHalfAngle + CONE_MARGIN, Math.PI * 0.5));

		for (LivingEntity mob : mobs) {
			Vec3 centre = mob.position().add(0.0, mob.getBbHeight() * 0.5, 0.0);
			Vec3 toMob = centre.subtract(eye);
			double distance = toMob.length();

			if (distance < 1.0E-3 || distance > range) {
				continue;
			}

			if (toMob.scale(1.0 / distance).dot(look) < cosLimit) {
				continue;
			}

			sampleMob(mob);
		}
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	private static void sampleMob(final LivingEntity mob) {
		Minecraft client = Minecraft.getInstance();
		EntityRenderDispatcher dispatcher = client.getEntityRenderDispatcher();

		try {
			EntityRenderer<?, ?> renderer = dispatcher.getRenderer(mob);
			if (!(renderer instanceof LivingEntityRenderer<?, ?, ?> livingRenderer)) {
				return;
			}

			LivingEntityRenderState state =
					(LivingEntityRenderState) ((EntityRenderer) renderer).createRenderState(mob, 1.0F);
			Model model = livingRenderer.getModel();
			model.setupAnim(state);

			int tint = textureColor(((LivingEntityRenderer) livingRenderer).getTextureLocation(state));

			// Same transform vanilla puts a living entity through before drawing its model.
			PoseStack poseStack = new PoseStack();
			poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - mob.yBodyRot));
			poseStack.scale(-1.0F, -1.0F, 1.0F);
			poseStack.translate(0.0F, -1.501F, 0.0F);

			double originX = mob.getX();
			double originY = mob.getY();
			double originZ = mob.getZ();
			RandomSource random = mob.getRandom();

			model.root().visit(poseStack, (pose, path, index, cube) ->
					sampleCube(pose, cube, originX, originY, originZ, tint, random));
		} catch (Exception ignored) {
			// Entity renderers are third-party surface; one uncooperative mob must not take the
			// whole scan down, so it is simply skipped this tick.
		}
	}

	/** Scatters points across the faces of one model cube, in world space. */
	private static void sampleCube(final PoseStack.Pose pose, final ModelPart.Cube cube,
			final double originX, final double originY, final double originZ,
			final int tint, final RandomSource random) {
		float sizeX = cube.maxX - cube.minX;
		float sizeY = cube.maxY - cube.minY;
		float sizeZ = cube.maxZ - cube.minZ;

		emitFace(pose, cube, sizeX, sizeY, 2, originX, originY, originZ, tint, random);
		emitFace(pose, cube, sizeX, sizeZ, 1, originX, originY, originZ, tint, random);
		emitFace(pose, cube, sizeZ, sizeY, 0, originX, originY, originZ, tint, random);
	}

	/**
	 * Emits both opposing faces along one axis. Sampling is jittered rather than gridded so
	 * repeated scans keep landing on fresh spots and the silhouette fills in over time.
	 *
	 * @param axis 0 for the two X faces, 1 for the Y faces, 2 for the Z faces
	 */
	private static void emitFace(final PoseStack.Pose pose, final ModelPart.Cube cube,
			final float width, final float height, final int axis,
			final double originX, final double originY, final double originZ,
			final int tint, final RandomSource random) {
		int samples = Math.max(2, Math.round(width * height / (SAMPLE_STEP * SAMPLE_STEP)));

		for (int side = 0; side < 2; side++) {
			for (int i = 0; i < samples; i++) {
				float u = random.nextFloat();
				float v = random.nextFloat();
				float x;
				float y;
				float z;

				if (axis == 0) {
					x = side == 0 ? cube.minX : cube.maxX;
					z = cube.minZ + (cube.maxZ - cube.minZ) * u;
					y = cube.minY + (cube.maxY - cube.minY) * v;
				} else if (axis == 1) {
					y = side == 0 ? cube.minY : cube.maxY;
					x = cube.minX + (cube.maxX - cube.minX) * u;
					z = cube.minZ + (cube.maxZ - cube.minZ) * v;
				} else {
					z = side == 0 ? cube.minZ : cube.maxZ;
					x = cube.minX + (cube.maxX - cube.minX) * u;
					y = cube.minY + (cube.maxY - cube.minY) * v;
				}

				Vector3f local = new Vector3f(x * MODEL_SCALE, y * MODEL_SCALE, z * MODEL_SCALE);
				pose.pose().transformPosition(local);

				LidarVision.rememberTinted(originX + local.x, originY + local.y, originZ + local.z, tint);
			}
		}
	}

	/**
	 * Average colour of a mob's texture, which is enough to keep a spider dark, a skeleton pale
	 * and a creeper green without reproducing the texture itself.
	 */
	private static int textureColor(final Identifier texture) {
		Integer cached = TEXTURE_COLORS.get(texture);
		if (cached != null) {
			return cached;
		}

		int color = 0xFFB0B0B0;

		try (InputStream stream = Minecraft.getInstance().getResourceManager().open(texture)) {
			try (NativeImage image = NativeImage.read(stream)) {
				long red = 0;
				long green = 0;
				long blue = 0;
				long counted = 0;

				for (int y = 0; y < image.getHeight(); y++) {
					for (int x = 0; x < image.getWidth(); x++) {
						int pixel = image.getPixel(x, y);
						if (((pixel >> 24) & 0xFF) < 128) {
							continue;
						}

						red += (pixel >> 16) & 0xFF;
						green += (pixel >> 8) & 0xFF;
						blue += pixel & 0xFF;
						counted++;
					}
				}

				if (counted > 0) {
					color = 0xFF000000
							| ((int) (red / counted) << 16)
							| ((int) (green / counted) << 8)
							| (int) (blue / counted);
				}
			}
		} catch (Exception ignored) {
			// Unreadable or procedural texture; the neutral grey fallback still shows the shape.
		}

		TEXTURE_COLORS.put(texture, color);
		return color;
	}
}
