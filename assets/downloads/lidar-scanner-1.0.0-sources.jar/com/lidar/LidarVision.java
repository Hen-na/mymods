package com.lidar;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side LiDAR point cloud.
 *
 * <p>While the scanner is held the world is rendered black (see the render mixins) and this
 * class is the only thing describing the environment: the scanner samples the geometry inside
 * its scan cone with many short raycasts and remembers every hit position for a while.
 *
 * <p>Points live in flat primitive arrays addressed by a ring cursor, with a long-keyed index
 * collapsing repeat hits onto the same slot. That keeps a very large cloud to a few megabytes
 * and, more importantly, keeps drawing it a straight array walk with no per-point objects.
 *
 * <p>All state here is per-client and deliberately not persisted anywhere.
 */
public final class LidarVision {
	/** Upper bound on remembered points; the oldest slot is recycled once this is reached. */
	private static final int MAX_POINTS = 200_000;

	/**
	 * How long a point survives after it was last hit by a scan, in ticks. Long enough that a
	 * scanned area stays usable as a temporary map while still fading out on its own.
	 */
	private static final int POINT_LIFETIME_TICKS = 6000;

	/** Raycasts fired per tick while scanning. */
	private static final int RAYS_PER_TICK = 110;

	/** Rays held on the scanner's axis each tick, so the centre of the scan always reads strongly. */
	private static final int CENTRAL_RAYS = 10;

	/**
	 * Ticks for the sweep to travel from the centre out to the rim before starting over. Short,
	 * so the scan reads as a rapid repeating pulse rather than a slow crawl.
	 */
	public static final int SWEEP_PERIOD_TICKS = 8;

	/** Radial thickness of the sweeping ring, as a fraction of the scan radius. */
	private static final double SWEEP_THICKNESS = 0.12;

	/** How far a sampling ray travels before giving up, in blocks. */
	private static final double SCAN_RANGE = 32.0;

	/** Edge length of the grid that collapses repeat hits onto one point, in blocks. */
	private static final double CELL = 0.25;

	/** Points beyond this distance from the eye are remembered but not drawn, in blocks. */
	private static final double DRAW_RANGE = 48.0;

	/** Distance over which the colour gradient runs its full warm-to-cold sweep, in blocks. */
	private static final double COLOR_RANGE = 32.0;

	/**
	 * Hue span of the gradient, as an HSV fraction: 0.0 is red and 0.75 is violet, passing
	 * through orange, yellow, green, cyan and blue on the way.
	 */
	private static final float HUE_SPAN = 0.75F;

	/** Resolution of the pre-built colour table. */
	private static final int DISTANCE_STEPS = 48;
	private static final int FADE_STEPS = 8;

	/** How far a tinted point is pulled toward the depth colour; the rest stays the mob's own. */
	private static final float DEPTH_MIX = 0.35F;

	/** Marks a slot that has never been written. */
	private static final int NEVER = Integer.MIN_VALUE;

	private static final double GOLDEN_ANGLE = Math.PI * (3.0 - Math.sqrt(5.0));

	/** Packed ARGB colours, built once and reused; drawing the cloud allocates nothing. */
	private static final int[][] COLOR_CACHE = new int[DISTANCE_STEPS][FADE_STEPS];
	private static final boolean[][] COLOR_CACHED = new boolean[DISTANCE_STEPS][FADE_STEPS];

	private static final double[] pointX = new double[MAX_POINTS];
	private static final double[] pointY = new double[MAX_POINTS];
	private static final double[] pointZ = new double[MAX_POINTS];
	private static final int[] pointSeen = new int[MAX_POINTS];
	private static final long[] pointKey = new long[MAX_POINTS];

	/** Base colour of a point, or 0 for block points which take their colour from depth alone. */
	private static final int[] pointTint = new int[MAX_POINTS];

	/** Grid key to slot, so re-scanning a surface refreshes points instead of duplicating them. */
	private static final Long2IntOpenHashMap slotByKey = new Long2IntOpenHashMap();

	/** Next slot to write, wrapping; slots are therefore recycled oldest-written first. */
	private static int cursor;

	/** How many slots have ever been written, so scans never walk the whole array early on. */
	private static int filled;

	/** Points not yet expired, refreshed once per tick and reported by the HUD. */
	private static int activePoints;

	/**
	 * The world is dark for its own sake, not because of what is in the player's hand. It is on
	 * whenever the player is in a level; the scanner is only the tool that reveals what is there.
	 */
	private static boolean darkness;

	/** Drives the HUD only. Scanning itself is driven by the item's own use behaviour. */
	private static boolean holdingScanner;

	/**
	 * Whether the LiDAR view is engaged. Toggling this off restores ordinary Minecraft rendering
	 * without touching the stored cloud, so switching back brings the same points straight back.
	 */
	private static boolean visionMode = true;

	private static int clientTick;

	static {
		slotByKey.defaultReturnValue(-1);
		java.util.Arrays.fill(pointSeen, NEVER);
	}

	/** Receives the points that are currently worth drawing. */
	public interface PointVisitor {
		void visit(double x, double y, double z, int argb);
	}

	/**
	 * Samples living entities inside the scan cone. Supplied by the client, because reaching a
	 * mob's model means touching renderer classes that do not exist on a server.
	 */
	public interface MobSampler {
		void sample(Level level, Player player, double coneHalfAngle);
	}

	private static MobSampler mobSampler;

	public static void setMobSampler(final MobSampler sampler) {
		mobSampler = sampler;
	}

	private LidarVision() {
	}

	/** True whenever the player is in a level and the LiDAR view is engaged. */
	public static boolean isDarknessActive() {
		return darkness && visionMode;
	}

	/** Flips between the LiDAR view and ordinary Minecraft rendering. Keeps every stored point. */
	public static void toggleVisionMode() {
		visionMode = !visionMode;
	}

	/** True only while the scanner is in one of the player's hands; gates the HUD. */
	public static boolean isHoldingScanner() {
		return holdingScanner;
	}

	public static void setDarknessActive(final boolean value) {
		darkness = value;
	}

	public static void setHoldingScanner(final boolean value) {
		holdingScanner = value;
	}

	/** Effective sampling range of the scanner, in blocks. Shown on the HUD. */
	public static int scanRange() {
		return (int) SCAN_RANGE;
	}

	/** Points currently held in the cloud. */
	public static int activePoints() {
		return activePoints;
	}

	/** Capacity of the point buffer. */
	public static int maxPoints() {
		return MAX_POINTS;
	}

	/** Drops everything; used when leaving a world so points never leak across levels. */
	public static void reset() {
		slotByKey.clear();
		java.util.Arrays.fill(pointSeen, NEVER);
		cursor = 0;
		filled = 0;
		activePoints = 0;
		darkness = false;
		holdingScanner = false;
		// Entering a world always starts in the LiDAR view.
		visionMode = true;
	}

	/**
	 * Samples the geometry inside the scan cone and remembers every hit.
	 *
	 * @param coneHalfAngle half-angle of the cone that produces the scanner's circular scan area
	 */
	public static void scan(final Level level, final Player player, final double coneHalfAngle) {
		Vec3 eye = player.getEyePosition(1.0F);
		Vec3 look = player.getViewVector(1.0F);

		Vec3 seed = Math.abs(look.y) > 0.9 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(0.0, 1.0, 0.0);
		Vec3 axisU = look.cross(seed).normalize();
		Vec3 axisV = look.cross(axisU).normalize();

		double spread = Math.tan(coneHalfAngle);
		RandomSource random = player.getRandom();

		// The sweep travels from the axis out to the rim and restarts, so the scan reads as rays
		// fanning outward from a central direction rather than the whole disc appearing at once.
		double sweep = (clientTick % SWEEP_PERIOD_TICKS) / (double) SWEEP_PERIOD_TICKS;

		for (int i = 0; i < RAYS_PER_TICK; i++) {
			double radial;

			if (i < CENTRAL_RAYS) {
				// The central scanning direction, kept tight against the axis.
				radial = random.nextDouble() * 0.05 * spread;
			} else {
				// A ring at the current sweep radius, softened so successive ticks overlap and
				// the disc ends up evenly covered over one sweep.
				double ring = sweep + (random.nextDouble() - 0.5) * SWEEP_THICKNESS;
				radial = Math.max(0.0, Math.min(1.0, ring)) * spread;
			}

			// Golden angle keeps successive rays from lining up, and the per-tick rotation stops
			// the pattern from freezing into one fixed spoke arrangement.
			double angle = i * GOLDEN_ANGLE + clientTick * 0.61;

			Vec3 direction = look
					.add(axisU.scale(Math.cos(angle) * radial))
					.add(axisV.scale(Math.sin(angle) * radial))
					.normalize();

			BlockHitResult hit = level.clip(new ClipContext(
					eye,
					eye.add(direction.scale(SCAN_RANGE)),
					ClipContext.Block.OUTLINE,
					ClipContext.Fluid.NONE,
					player));

			if (hit.getType() == HitResult.Type.BLOCK) {
				remember(hit.getLocation().x, hit.getLocation().y, hit.getLocation().z, 0);
			}
		}

		if (mobSampler != null) {
			mobSampler.sample(level, player, coneHalfAngle);
		}
	}

	/**
	 * Records a point carrying its own base colour, used for mobs so they stay recognisable.
	 * The position is whatever it was at the moment of the scan; nothing tracks the mob after.
	 */
	public static void rememberTinted(final double x, final double y, final double z, final int tint) {
		remember(x, y, z, tint);
	}

	/** Ages the cloud out and refreshes the count the HUD reports. */
	public static void tick() {
		clientTick++;

		int alive = 0;
		for (int slot = 0; slot < filled; slot++) {
			int seen = pointSeen[slot];
			if (seen != NEVER && clientTick - seen <= POINT_LIFETIME_TICKS) {
				alive++;
			}
		}

		activePoints = alive;
	}

	/**
	 * Walks the live, in-range part of the cloud. Colour is resolved here so the renderer only
	 * has to turn positions into quads.
	 */
	public static void forEachVisiblePoint(final Vec3 eye, final PointVisitor visitor) {
		double drawRangeSq = DRAW_RANGE * DRAW_RANGE;

		for (int slot = 0; slot < filled; slot++) {
			int seen = pointSeen[slot];
			if (seen == NEVER) {
				continue;
			}

			int age = clientTick - seen;
			if (age > POINT_LIFETIME_TICKS) {
				continue;
			}

			double dx = pointX[slot] - eye.x;
			double dy = pointY[slot] - eye.y;
			double dz = pointZ[slot] - eye.z;
			double distanceSq = dx * dx + dy * dy + dz * dz;
			if (distanceSq > drawRangeSq) {
				continue;
			}

			float freshness = 1.0F - age / (float) POINT_LIFETIME_TICKS;
			int argb = pointColor(Math.sqrt(distanceSq), freshness, pointTint[slot]);
			visitor.visit(pointX[slot], pointY[slot], pointZ[slot], argb);
		}
	}

	private static void remember(final double x, final double y, final double z, final int tint) {
		long key = key(x, y, z);

		int existing = slotByKey.get(key);
		if (existing >= 0 && pointKey[existing] == key) {
			pointSeen[existing] = clientTick;
			pointTint[existing] = tint;
			return;
		}

		int slot = cursor;
		cursor = cursor + 1 == MAX_POINTS ? 0 : cursor + 1;
		if (filled < MAX_POINTS) {
			filled++;
		}

		// Recycling a slot has to drop whatever key used to point at it, or the index would
		// keep growing and hand out stale slots.
		if (pointSeen[slot] != NEVER) {
			slotByKey.remove(pointKey[slot]);
		}

		pointX[slot] = x;
		pointY[slot] = y;
		pointZ[slot] = z;
		pointSeen[slot] = clientTick;
		pointKey[slot] = key;
		pointTint[slot] = tint;
		slotByKey.put(key, slot);
	}

	/**
	 * Packs a quantised position into a map key. Each axis keeps 21 bits, so two positions only
	 * collide when they are more than 500k blocks apart, which cannot happen inside one cloud.
	 */
	private static long key(final double x, final double y, final double z) {
		long qx = (long) Math.floor(x / CELL) & 0x1FFFFFL;
		long qy = (long) Math.floor(y / CELL) & 0x1FFFFFL;
		long qz = (long) Math.floor(z / CELL) & 0x1FFFFFL;
		return (qx << 42) | (qy << 21) | qz;
	}

	/**
	 * Distance drives the hue and age drives the brightness, so depth reads as colour while the
	 * existing fade still dims a point as it gets old.
	 *
	 * <p>The gradient sweeps red - orange - yellow - green - cyan - blue - violet continuously,
	 * quantised only finely enough to keep the lookup table small; points at the same distance
	 * always land on the same colour.
	 */
	private static int pointColor(final double distance, final float freshness, final int tint) {
		int distanceStep = Mth.clamp(
				(int) (distance / COLOR_RANGE * (DISTANCE_STEPS - 1) + 0.5F), 0, DISTANCE_STEPS - 1);
		int fadeStep = Mth.clamp((int) (freshness * (FADE_STEPS - 1) + 0.5F), 0, FADE_STEPS - 1);

		if (!COLOR_CACHED[distanceStep][fadeStep]) {
			float depth = distanceStep / (float) (DISTANCE_STEPS - 1);
			COLOR_CACHE[distanceStep][fadeStep] =
					Mth.hsvToArgb(depth * HUE_SPAN, 1.0F, brightness(distanceStep, fadeStep), 255);
			COLOR_CACHED[distanceStep][fadeStep] = true;
		}

		int spectrum = COLOR_CACHE[distanceStep][fadeStep];
		if (tint == 0) {
			return spectrum;
		}

		// A mob keeps most of its own colour so it stays identifiable, but is pulled part of the
		// way toward the depth hue and dimmed by the same fade, so it still reads as LiDAR data.
		float shade = brightness(distanceStep, fadeStep);
		int red = blend((tint >> 16) & 0xFF, (spectrum >> 16) & 0xFF, shade);
		int green = blend((tint >> 8) & 0xFF, (spectrum >> 8) & 0xFF, shade);
		int blue = blend(tint & 0xFF, spectrum & 0xFF, shade);
		return 0xFF000000 | (red << 16) | (green << 8) | blue;
	}

	private static int blend(final int tintChannel, final int spectrumChannel, final float shade) {
		float value = tintChannel * shade * (1.0F - DEPTH_MIX) + spectrumChannel * DEPTH_MIX;
		return Mth.clamp((int) value, 0, 255);
	}

	/** Close points sit a little brighter as well as warmer, but far ones stay legible. */
	private static float brightness(final int distanceStep, final int fadeStep) {
		float depth = distanceStep / (float) (DISTANCE_STEPS - 1);
		return fadeStep / (float) (FADE_STEPS - 1) * (0.75F + 0.25F * (1.0F - depth));
	}
}
